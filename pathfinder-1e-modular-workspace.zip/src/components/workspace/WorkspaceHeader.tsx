import React from 'react';
import {
  Layers,
  Dices,
  Heart,
  Printer,
  Clock,
  Terminal,
  FilePlus,
  FolderOpen,
  User,
  FileCode,
  BookOpen,
  Cpu,
} from 'lucide-react';
import { useCharacter } from '../../context/CharacterContext';
import { AppleEyeIcon } from '../common/AppleEyeIcon';
import { SaveButton } from '../storage/SaveButton';
import { AutosaveState } from '../../storage/useAutosave';
import { ImageBrowserTargetConfig } from '../../engine/characterIntegration';

interface WorkspaceHeaderProps {
  isSidebarCollapsed: boolean;
  onToggleSidebar: () => void;
  onOpenImageBrowser: (config?: Partial<ImageBrowserTargetConfig>) => void;
  onOpenNewSheet: () => void;
  onOpenStepper: () => void;
  onOpenDeck: () => void;
  onOpenXDX: () => void;
  onOpenDice: () => void;
  onOpenQuickHP: () => void;
  onOpenJournal: () => void;
  isCompleteSheetOpen: boolean;
  onToggleCompleteSheet: () => void;
  onOpenAITool: (tab?: string) => void;
  onOpenPrintView: () => void;
  autosaveState: AutosaveState;
}

export const WorkspaceHeader: React.FC<WorkspaceHeaderProps> = ({
  isSidebarCollapsed,
  onToggleSidebar,
  onOpenImageBrowser,
  onOpenNewSheet,
  onOpenStepper,
  onOpenDeck,
  onOpenXDX,
  onOpenDice,
  onOpenQuickHP,
  onOpenJournal,
  isCompleteSheetOpen,
  onToggleCompleteSheet,
  onOpenAITool,
  onOpenPrintView,
  autosaveState,
}) => {
  const {
    character,
    setCharacter,
    layout,
    setLayout,
    isExportingHTML,
    exportStandaloneHTML,
  } = useCharacter();

  return (
    <header className="h-14 bg-slate-950 border-b border-slate-800 text-slate-100 px-4 md:px-6 flex items-center justify-between gap-6 shrink-0 z-20 print:hidden select-none">
      {/* Zone 1: Wordmark & Core Identity */}
      <div className="flex items-center gap-2.5 shrink-0">
        <button
          onClick={onToggleSidebar}
          className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-cyan-400 border border-slate-800 transition-colors"
          title={isSidebarCollapsed ? 'Show Blueprint Sidebar' : 'Hide Blueprint Sidebar'}
        >
          <Layers className="w-4 h-4" />
        </button>
        <span className="font-serif font-black tracking-tight text-amber-300 text-sm md:text-base whitespace-nowrap">
          Pathfinder 1e{' '}
          <span className="font-sans font-light text-slate-400 text-xs hidden sm:inline">
            | Modular Workspace
          </span>
        </span>

        {/* Profile Picture thumbnail / button */}
        <button
          onClick={() =>
            onOpenImageBrowser({
              targetType: 'profile',
              title: 'Character Profile Picture Browser',
              subtitle:
                'Choose an avatar from local files, fantasy portraits, or enter an image URL.',
              currentUrl:
                character.profileData?.avatarUrl || character.characterBio?.portraits?.[0],
            })
          }
          className="flex items-center gap-1.5 p-1 pr-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/50 text-slate-300 transition-all group"
          title="Click to browse character profile picture"
        >
          <div className="w-6 h-6 rounded-full overflow-hidden border border-cyan-500/50 bg-black/60 shrink-0 flex items-center justify-center">
            {character.profileData?.avatarUrl || character.characterBio?.portraits?.[0] ? (
              <img
                src={character.profileData?.avatarUrl || character.characterBio?.portraits?.[0]}
                alt="Avatar"
                className="w-full h-full object-cover"
              />
            ) : (
              <User className="w-3.5 h-3.5 text-cyan-400" />
            )}
          </div>
          <span className="text-xs font-mono hidden md:inline-block group-hover:text-cyan-300 font-semibold truncate max-w-[130px]">
            {character.name || 'Unnamed'} (Lvl {character.level})
          </span>
        </button>

        {/* Clear All / New Sheet Button */}
        <button
          onClick={onOpenNewSheet}
          className="px-2.5 py-1 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/40 hover:border-rose-400 text-rose-300 text-xs font-mono font-bold flex items-center gap-1.5 transition-colors shadow-xs"
          title="Clear all / Start a fresh new character sheet"
        >
          <FilePlus className="w-3.5 h-3.5 text-rose-400" />
          <span className="hidden sm:inline">New Sheet</span>
        </button>
      </div>

      {/* Zone 2: Sheet Navigation & Viewport Tabs */}
      <nav className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-lg border border-slate-800 shrink-0">
        {[
          { id: 1, label: 'Page 1: Core Combat' },
          { id: 2, label: 'Page 2: Actions & Skills' },
          { id: 3, label: 'Page 3: Bio & Storage' },
          { id: 4, label: 'Page 4: DSL Studio' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              setLayout((prev) => ({
                ...prev,
                activeSheet: tab.id as 1 | 2 | 3 | 4,
                showAllSheets: false,
              }));
            }}
            className={`px-3 py-1 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
              layout.activeSheet === tab.id && !layout.showAllSheets
                ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
        <button
          onClick={() => setLayout((prev) => ({ ...prev, showAllSheets: !prev.showAllSheets }))}
          className={`px-3 py-1 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
            layout.showAllSheets
              ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          All 3 Pages
        </button>
      </nav>

      {/* Zone 3: Quick Live Action Bar */}
      <div className="flex items-center gap-1.5 shrink-0">
        {/* File Browser for Images & Gear Art */}
        <button
          onClick={() =>
            onOpenImageBrowser({
              targetType: 'profile',
              title: 'Image & File Browser (Portraits, Items, Gallery)',
              subtitle:
                'Browse local files from your computer, choose fantasy items/portraits, or link an image.',
              currentUrl:
                character.profileData?.avatarUrl || character.characterBio?.portraits?.[0],
            })
          }
          className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-cyan-500/40 hover:border-cyan-400 text-cyan-300 text-xs font-mono flex items-center gap-1.5 transition-colors"
          title="Image File Browser: Character portraits, item icons, and fantasy presets"
        >
          <FolderOpen className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden lg:inline">Images</span>
        </button>

        {/* Stepper Tool */}
        <button
          onClick={onOpenStepper}
          className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-amber-300 text-xs font-mono flex items-center gap-1.5 transition-colors"
          title="Open Turn Stepper"
        >
          <Clock className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden sm:inline">Stepper</span>
        </button>

        {/* Deck Tool */}
        <button
          onClick={onOpenDeck}
          className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-cyan-300 text-xs font-mono flex items-center gap-1.5 transition-colors"
          title="Open Deck Simulator"
        >
          <Layers className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden sm:inline">Deck</span>
        </button>

        {/* XDX Tool */}
        <button
          onClick={onOpenXDX}
          className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-amber-300 text-xs font-mono flex items-center gap-1.5 transition-colors"
          title="Open XDX Macro Center"
        >
          <Terminal className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden sm:inline">XDX</span>
        </button>

        <button
          onClick={onOpenDice}
          className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-amber-300 text-xs font-mono flex items-center gap-1.5 transition-colors"
          title="Open Dice Tray"
        >
          <Dices className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden md:inline">Dice</span>
        </button>

        <button
          onClick={onOpenQuickHP}
          className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-rose-300 text-xs font-mono flex items-center gap-1.5 transition-colors"
          title="Adjust HP"
        >
          <Heart className="w-3.5 h-3.5 text-rose-500" />
          <span>
            {character.hpCurrent}/{character.hpTotalMax}
          </span>
        </button>

        {/* Session Journal & Chronicle Button */}
        <button
          onClick={onOpenJournal}
          className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-amber-300 text-xs font-mono flex items-center gap-1.5 transition-colors"
          title="Open Session Journal, Notes & Field Sketches"
        >
          <BookOpen className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden sm:inline">Journal</span>
        </button>

        {/* AI Companion Quick Tool Button (shown if module installed) */}
        {character.installedModules?.aiCompanion && (
          <>
            <button
              onClick={onToggleCompleteSheet}
              className={`px-2.5 py-1.5 rounded-lg border text-xs font-mono flex items-center gap-1.5 transition-colors shadow-xs ${
                isCompleteSheetOpen
                  ? 'bg-cyan-600 border-cyan-300 text-white shadow-cyan-500/20'
                  : 'bg-gradient-to-r from-emerald-950/80 to-cyan-950/80 hover:from-emerald-900 hover:to-cyan-900 border-emerald-500/50 text-emerald-300'
              }`}
              title="Toggle AI Complete Sheet (Conversational Build from Concept mini-window)"
            >
              <AppleEyeIcon className="w-3.5 h-3.5 text-cyan-300" />
              <span className="hidden sm:inline">Complete Sheet</span>
            </button>

            <button
              onClick={() => onOpenAITool('permissions')}
              className="px-2.5 py-1.5 rounded-lg bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-500/50 text-cyan-300 text-xs font-mono flex items-center gap-1.5 transition-colors shadow-xs"
              title="Open AI Companion Listener Settings & Module Permissions"
            >
              <Cpu className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">AI Tool</span>
            </button>
          </>
        )}

        {/* Standalone HTML Export Button */}
        <button
          onClick={exportStandaloneHTML}
          disabled={isExportingHTML}
          className="px-2.5 py-1.5 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/50 hover:border-emerald-400 text-emerald-300 text-xs font-mono font-bold flex items-center gap-1.5 transition-colors shadow-xs"
          title="Export complete standalone single-file HTML sheet to share with friends or host anywhere"
        >
          <FileCode className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden xl:inline">
            {isExportingHTML ? 'Packaging...' : 'Export HTML'}
          </span>
        </button>

        {/* Print / Download PDF View Button */}
        <button
          onClick={onOpenPrintView}
          className="px-2.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-slate-950 text-xs font-mono font-bold flex items-center gap-1.5 transition-colors"
          title="Open 3-Section Print View & Download PDF"
        >
          <Printer className="w-4 h-4" />
          <span className="hidden xl:inline">Download PDF</span>
        </button>

        {/* Save CD/Disc Button + Connection Status Dot + Connect Folder + Crash Autosave Label */}
        <SaveButton
          character={character}
          autosaveState={autosaveState}
          onCharacterLoaded={(loaded) => setCharacter(loaded)}
        />
      </div>
    </header>
  );
};

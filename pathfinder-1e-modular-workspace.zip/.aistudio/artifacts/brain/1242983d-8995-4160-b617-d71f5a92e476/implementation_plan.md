# AI Complete Sheet: Conversational Character Builder from SOT & Concept

Build a conversational AI character creation engine housed in a floating, draggable mini-window over the active sheet. The chatbot talks like a friend collaborating on a build, mirrors the user's conversational vibe, grounds all mechanical options strictly in loaded Source of Truth (SOT) SRDs/links without fabricating rules, auto-populates character fields in real-time through Broad Sheet Authority with instant feedback badges, and provides an inline SOT upload shortcut whenever unindexed rules are needed.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural decisions were confirmed in Phase 1 interactive clarification:
> - **Window Presentation**: Floating draggable mini-window over the active sheet (with minimize, maximize, and popout controls, launchable from both the AI Companion modal and the header action bar).
> - **Sheet Update Paradigm**: Live auto-populate with instant feedback badges as the conversation progresses, applying field updates in real time through Broad Sheet Authority while strictly respecting AI Blind Spot permissions.
> - **Unmatched Rules Handling**: Strict SOT fidelity (zero hallucinated rules). When a requested archetype, feat, or ability is not present in SOT docs or links, the AI pauses, explains what is missing, and provides a 1-click inline shortcut to upload or paste the SRD directly into SOT.
> - **Randomized Assignment**: The AI assigns random stats, traits, or details **only** when the user explicitly prompts it to do so (e.g., "roll random stats for me" or "pick a random feat from my SOT").

---

## 1. Overview & Core Concept

The **Complete Sheet** subtool is the flagship feature of the AI Companion. Rather than requiring players to manually navigate across 19 separate sheet modules, the player opens a floating conversation window to brainstorm a character concept (e.g., *"I want to make an agile Slayer who dual-wields kukris in the Patrivia marsh"*).

Behind the scenes:
1. **SOT Grounding**: The AI indexes all loaded SOT SRD documents (browser page dumps, house rules, class tables) and SOT verified weblinks.
2. **Friendly Peer Persona**: The assistant writes in natural, peer-to-peer tabletop enthusiast language—matching the user's enthusiasm, brevity, and tone, rather than sounding like an impersonal search bot or corporate assistant.
3. **Broad Sheet Authority Integration**: As the build develops (Ability scores, Hit Dice, BAB, Saves, Feats, Action Directory resources, Skills, Proficiencies, Bio, and Equipment), the engine transforms conversation milestones into structured sheet mutations.
4. **Live Badge Feedback**: Every mutation emits a visual update chip (e.g., `+ Added Studied Target to Actions`, `+ Set STR 14, DEX 18`, `+ Unlocked Stealth & Acrobatics`) directly in the conversation thread and sheet viewport.
5. **No Rule Guessing**: If a player asks for a 3rd-party archetype or feat not in the SOT, the AI halts, states what source is missing, and opens an inline **"Quick Add to SOT"** drawer so the user can paste the text and resume building immediately.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Discovery & Launch**:
   - The user opens the **AI Companion Modal** and clicks the primary feature card: **Complete Sheet (Concept to Build)**, or clicks the **Complete Sheet** floating action pill in the top header.
   - A sleek, floating mini-window opens anchored to the bottom-right of the character sheet viewport.
2. **Concept Ideation & Chat**:
   - The bot greets the player warmly: *"Hey! Let's build this character. What kind of concept or class are you envisioning for this campaign?"*
   - As the player talks, the bot suggests archetypes, stats, and feat progressions found in the loaded SOT SRDs.
3. **Live Auto-Population & Badges**:
   - When the player agrees or specifies choices (*"Let's go with Slayer 12, focusing on two-weapon fighting and high Dex"*), the AI calls Broad Sheet Authority.
   - The conversation displays glowing green **Applied Badges** detailing what was populated. The underlying character sheet updates immediately in the background.
4. **Missing SOT Prompt & Inline Quick-Add**:
   - If the player mentions a feat or archetype not yet indexed (*"Can I use the Stygian Slayer archetype?"*), the AI responds: *"Stygian Slayer isn't in your loaded SOT docs yet! Paste the archetype text or link below and I'll adapt it right into your grid."*
   - An inline quick-upload box allows dragging a file or pasting raw text directly into SOT, automatically locking it as Read-Only and continuing the build.
5. **Window Controls**:
   - The mini-window supports dragging by the title bar, minimize to a floating bubble, maximize to full canvas, and a 1-click **"Inspect Sheet Changes"** tab.

### Visual Design & Aesthetics (Adhering to Universal Frontend Design)
- **Geometry & Palette**:
  - The floating window uses a clean, tactile design matched to the active theme (warm dark slate with cyan/amber accents in Blueprint/Dark mode; authentic parchment tan with charcoal typography in Parchment mode).
  - Subtle hairline borders (`border border-cyan-500/30 dark:border-slate-800`), smooth shadow elevation (`shadow-2xl`), and rounded-xl containers with zero pill badges.
- **Typography**:
  - Message titles and character names use the font-serif display style (`Cinzel` / `Times`), body text uses legible prose with comfortable line height, and mechanics/formula tags use `font-mono tabular-nums`.
- **Anti-Slop Discipline**:
  - No fake corporate buzzwords, no decorative pulsing dots, no artificial "AI Confidence 98%" gauges.
  - Interactive buttons use clear human verbs: `"Apply to Sheet"`, `"Quick Add SOT"`, `"Reroll Array"`, `"Close"`.

---

## 3. Key Product Decisions & Trade-Offs

### Decision 1: Floating Draggable Window vs. Modal Tab
- **Chosen Approach**: A floating, draggable mini-window rendered at the root viewport level over the active sheet canvas, with minimize/maximize toggles.
- **Rationale**: Building a character is an iterative, visual task. If the chat is trapped inside a static full-screen modal, the player cannot see their sheet update in real time. A floating window allows immediate visual gratification as HP, BAB, skills, and feats pop onto the sheet.
- **Alternative Considered**: Keeping it as Tab 6 inside the existing `AICompanionModal.tsx`. Passed over because it hides the sheet canvas during generation.

### Decision 2: Server-Side Gemini Route (`/api/gemini/complete-sheet`)
- **Chosen Approach**: Use a dedicated Express server endpoint (`POST /api/gemini/complete-sheet`) calling `@google/genai` with model `'gemini-3.8-flash'`.
- **Rationale**: Complies strictly with the `@google/genai` skill guidelines (server-side only, no client API keys, telemetry headers). The endpoint receives the conversation history, current character snapshot, active SOT documents/links, and blind-spot permissions, returning both a natural conversational response and an array of structured `SheetModificationAction` updates.
- **Alternative Considered**: Pure client-side regex parsing without LLM inference. Passed over because natural concept discussion (*"give me something sneaky with a big greatsword"*) requires genuine semantic understanding and SRD synthesis.

### Decision 3: Strict SOT Zero-Guessing Policy
- **Chosen Approach**: The AI prompt explicitly enforces that all mechanical rules (names, bonuses, requirements, DC formulas) must be sourced strictly from the provided SOT context. When missing, the AI triggers the quick-upload flow rather than inventing rules.
- **Rationale**: Prevents hallucinated Pathfinder 1e feats or math errors. Ensures the sheet remains a trusted tabletop reference.

---

## 4. Technical Architecture & Data Strategy

### ASCII Architecture & Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                             CLIENT VIEWPORT                                 │
│                                                                             │
│  ┌───────────────────────┐             ┌─────────────────────────────────┐  │
│  │ Active Character Sheet│             │ AI Complete Sheet Mini-Window   │  │
│  │ (Core, Actions, Bio)  │◄────────────│ (Draggable, Chat, SOT Grounding)│  │
│  └───────────────────────┘ Live Update └────────────────┬────────────────┘  │
│             ▲                                           │                   │
│             │                                           │ POST Chat + SOT   │
│             │                                           ▼ Context           │
│  ┌──────────┴────────────┐             ┌─────────────────────────────────┐  │
│  │ Broad Sheet Authority │             │ Express Backend:                │  │
│  │ & Blind Spot Filter   │             │ POST /api/gemini/complete-sheet │  │
│  └───────────────────────┘             └────────────────┬────────────────┘  │
│                                                         │                   │
│                                                         │ @google/genai SDK │
│                                                         ▼                   │
│                                        ┌─────────────────────────────────┐  │
│                                        │ Gemini 3.8 Flash Engine         │  │
│                                        │ (SOT Grounded, Structured JSON) │  │
│                                        └─────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Component & State Mapping

1. **`src/components/tools/CompleteSheetChatWindow.tsx` (New Component)**:
   - Manages floating position (`x`, `y`), drag interactions, minimized bubble state, and chat history.
   - Renders message history with distinct role styles (User vs. Friendly AI companion).
   - Renders **Live Applied Badges** for every action applied to the character sheet.
   - Contains an expandable **Quick SOT Upload Drawer** to paste or upload an SRD directly during the conversation.
2. **`src/engine/aiService.ts` Updates**:
   - `completeSheetConverse()` function: Calls `/api/gemini/complete-sheet` with conversation messages, current character state, SOT catalog data, and permission blind spots.
   - Integrates with `parseNaturalLanguageSheetUpdates()` and broad sheet authority to execute updates safely on `PF1Character`.
3. **`server.ts` Endpoint**:
   - Route `POST /api/gemini/complete-sheet`:
     - Reads SOT override pages and single-page read-only snapshots.
     - Formats system instructions: peer companion tone, SOT-only grounding, zero hallucinated mechanics, structured JSON response with `replyText` and `fieldUpdates[]`.
     - Uses `@google/genai` with model `gemini-3.8-flash`.
4. **App Wiring**:
   - In `src/App.tsx`, mount `<CompleteSheetChatWindow />` conditionally when `isCompleteSheetOpen` is true.
   - Add launch button in `AICompanionModal.tsx` and in the sheet header toolbar.
